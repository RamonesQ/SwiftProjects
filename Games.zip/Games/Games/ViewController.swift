//
//  ViewController.swift
//  Games
//
//  Created by Ramon Queiroz dos Santos on 09/09/22.
//

import UIKit

class ViewController: UIViewController {

	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view.
	}


}

